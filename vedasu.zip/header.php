<!-- Top navigation -->
<div class="topnav">

  <!-- Centered link -->
  <!-- <div class="topnav-centered">
    <a href="#home" class="active">Home</a>
  </div> -->

  
  <!-- Left-aligned links (default) -->
  <a href="index.php">Home</a>
  <a href="addproduct.php">Add Product</a>
  <a href="viewcart.php">View cart</a>
  <a href="checkout.php">Check Out</a>
  
  <!-- Right-aligned links -->
  <div class="topnav-right">
    <a href="#search">Search</a>
    <a href="#about">About</a>
  </div>
  
</div>